import rospy
from geometry_msgs.msg import PoseStamped

def main():
    # Init node
    rospy.init_node("publish_goal")

    # Initialise goal data structure
    goal = PoseStamped()

    # Setup a publisher
    pub = rospy.Publisher('/move_base_simple/goal', PoseStamped, queue_size=1)

    # Populate some values
    goal.header.stamp = rospy.Time.now()
    goal.header.frame_id = "map"
    goal.pose.position.x = 1.0
    goal.pose.position.y = 0.5
    goal.pose.position.z = 0.0
    goal.pose.orientation.x = 0.0
    goal.pose.orientation.y = 0.0
    goal.pose.orientation.z = 0.0
    goal.pose.orientation.w = 1.0

    # actually publish the data
    while pub.get_num_connections() == 0:
        rospy.loginfo("Waiting for someone to subscribe...")
    pub.publish(goal)

    # # block execution
    rospy.spin()


if __name__ == "__main__":
    try:
        main()
    except rospy.ROSInterruptException:
        pass